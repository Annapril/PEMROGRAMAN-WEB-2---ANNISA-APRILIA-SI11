<?php 
class Pasien {
    public $nama;
    public $gender;
    public $kode;
}
?>